package com.sweetshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SweetShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SweetShopApplication.class, args);
	}

}
